lr = [ 0.03 0.035 0.04 0.045 0.05 0.06 0.07 0.08 ];

for i = 1:numel( lr )
	learning_rate = lr(i)
	a4_main( 300, learning_rate, .005, 1000 )
end